test = {
  'name': 'Question',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> nparray4
          array([[3, 3, 3],
                 [3, 3, 3],
                 [3, 3, 3],
                 [6, 6, 6],
                 [6, 6, 6],
                 [6, 6, 6]])

          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
